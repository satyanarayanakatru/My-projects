import React, { useState } from 'react';
import { Route, Routes } from 'react-router-dom';
import "../node_modules/font-awesome/css/font-awesome.min.css";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js";
import Navbar from './components/Navbar.js';
import  Home  from './pages/Home.js';
import  Products  from './pages/Products.js';
import Contact from './pages/Contact.js';
import Footer from './components/Footer.js';
import Hotdeals from './pages/Hotdeals.js';
import About from './pages/About.js';
import NoPageFound from './pages/NoPageFound.js';
import OrderPlace from './pages/OrderPlace.js';
import Submit from './pages/Submit.js';
import "./css/style.css";
import './css/responsive.css';
import './App.css';

function App() {
  const [index, setIndex] = useState(0);
  return (
    <div>
      <Navbar/>
      <Routes>
        <Route path='' element={<Home/>}/>
        <Route path='/products' element={<Products/>}/>
        <Route path='/contact' element={<Contact/>}/>
        <Route path='/hotdeals' element={<Hotdeals/>}/>
        <Route path='/about' element={<About/>}/>
        <Route path='/orderplace' element={<OrderPlace/>}/>
        <Route path='/submit' element={<Submit/>}/>
        <Route path='*' element={<NoPageFound/>}/>
      </Routes>
      <Footer/>
    </div>
  )
}

export default App;