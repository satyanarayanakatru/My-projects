import React from 'react';
import Responsive from './Slider'

function Newarrivals() {
    return (
        <div>
            <div className='new_arrivals'>
                <div className='container'>
                    <h2>NEW <span>ARRIVALS</span> </h2>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
                    <Responsive/>
                </div>
            </div>
        </div>
    )
}

export default Newarrivals