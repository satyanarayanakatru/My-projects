import React from 'react'
import product_img4 from "../images/Product-Img4.png";
import Newarrivals from './Newarrivals';
import Newsletter from './Newsletter';
import { useNavigate } from 'react-router-dom';


function Main() {

    const navigate = useNavigate();

    const products = [
        {
            name: "Reebok Ladies Jacket",
            price: "80$",
        },
        {
            name: "Reebok Gents Jacket",
            price: "100$",
        },
        {
            name: "Gents Men Jacket",
            price: "70$",
        },
        {
            name: "Ladies Jacket",
            price: "60$",
        },
    ]


    return (
        <div>
            <div className='main'>
                <div className='banner'>
                    <div className='container'>
                        <div className='banner_content'>
                            <h2>FULL WINTER KIT</h2>
                            <p>Half Jacket + Skiny Trousers + Boot leather</p>
                            <p className='banner_content_para'>Lorem Ipsum is simply dummy text of the printing and typesetting industry </p>
                            <span>Price : 120$</span>
                            <span><i className='fa fa-shopping-cart'>&nbsp;<button className='home_order_btn' onClick={()=>navigate('/orderplace')}>Order now</button></i></span>
                        </div>
                    </div>
                </div>
                <Newarrivals/>
                <div className='best_sales'>
                    <div className='container'>
                        <h2><span>BEST</span> SALES</h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
                        <div className='best_sales_inner_content'>
                            <div className='best_sales_content fix'>
                                <img src={product_img4}></img>
                                <h2>Reebok Track Jacket</h2>
                                <p>
                                    <i className='fa fa-star text-danger'></i>
                                    <i className='fa fa-star text-danger'></i>
                                    <i className='fa fa-star text-danger'></i>
                                    <i className='fa fa-star-o'></i>
                                    <span className='price'>100$</span>
                                </p>
                            </div>
                            <div className='best_sales_content fix'>
                                <img src={product_img4}></img>
                                <h2>Reebok Track Jacket</h2>
                                <p>
                                    <i className='fa fa-star text-danger'></i>
                                    <i className='fa fa-star text-danger'></i>
                                    <i className='fa fa-star text-danger'></i>
                                    <i className='fa fa-star-o'></i>
                                    <span className='price'>100$</span>
                                </p>
                            </div>
                            <div className='best_sales_content fix' >
                                <img src={product_img4}></img>
                                <h2>Reebok Track Jacket</h2>
                                <p>
                                    <i className='fa fa-star text-danger'></i>
                                    <i className='fa fa-star text-danger'></i>
                                    <i className='fa fa-star text-danger'></i>
                                    <i className='fa fa-star-o'></i>
                                    <span className='price'>100$</span>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <Newsletter/>
            </div>
        </div>
    )
}

export default Main;