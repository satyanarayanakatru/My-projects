import React from 'react'

function Newsletter() {
  return (
    <>
      <div className='news_letter_content'>
        <div className='container'>
          <div className='news_letter fix'>
            <div className='news_letter_left_content'>
              <p><span>NEWS LETTER</span>join us now to get all news and special offers</p>
            </div>
            <div className='news_letter_right_content'>
              <p><i className='fa fa-envelope'></i>
              <input type='mail' placeholder='type your email here'></input>
              </p>
              <button>join us</button>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default Newsletter