import React from 'react'
import logo from '../images/logo.png';
import { NavLink } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';

function Navbar() {

    function myFunction(x,y) {
        var x = document.getElementById("nav_bar");
        var y = document.getElementById("hamburger");
        if (x.style.display === "block") {
            x.style.display = "none";
        } else {
            x.style.display = "block";   
        }
        y.classList.toggle("change");
    }

    const navigate = useNavigate();

    return (

        <div>
            <div className='header'>
                <div className='container fix'>
                    <div className='small_header'>
                        <span><i className="fa fa-envelope-o"></i>info@shopy.com</span>
                        <span><i className="fa fa-phone" aria-hidden="true"></i>8179795623</span>
                    </div>
                    <div className='header_icons'>
                        <a href="https://www.facebook.com"><i className='fa fa-facebook'></i></a>
                        <a href="https://www.twitter.com"><i className='fa fa-twitter'></i></a>
                        <a href="https://www.google.com"><i className='fa fa-google-plus'></i></a>
                        <a href="https://www.instagram.com"><i className='fa fa-instagram'></i></a>
                    </div>
                </div>
                <hr></hr>
                <div className='container'>
                    <div className='big_header fix'>
                        <a href='#' className='logo' onClick={() => navigate('')}><img src={logo}></img></a>
                        <div className="ham_menu" id='hamburger' onClick={myFunction}>
                            <div className="bar1"></div>
                            <div className="bar2"></div>
                            <div className="bar3"></div>
                        </div>
                        <nav id='nav_bar'>
                            <ul>
                                <li><NavLink to={""}>Home</NavLink></li>
                                <li><NavLink to={"products"}>Products</NavLink></li>
                                <li><NavLink to={"hotdeals"}>Hot Deals</NavLink></li>
                                <li><NavLink to={"about"}>About</NavLink></li>
                                <li><NavLink to={"contact"}>Contact</NavLink></li>
                            </ul>
                            <div className='icons'>
                                <i className='fa fa-search'></i>
                                <i className="fa fa-user-plus" aria-hidden="true"></i>
                                <i className='fa fa-shopping-cart'></i>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Navbar;