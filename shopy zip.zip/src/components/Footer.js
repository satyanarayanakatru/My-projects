import React from 'react'
import logo from '../images/logo.png';
import payment from '../images/Payment-Images.png'

function Footer() {
    return (
        <div className='footer'>
            <div className='container footer_inner_content'>
                <div className='footer_content'>
                    <img src={logo}></img>
                    <p>shopy c 2015 . your copy right here</p>
                </div>
                <div className='footer_content'>
                    <ul>
                        <li>about us</li>
                        <li>contact us</li>
                        <li>support us</li>
                    </ul>
                </div>
                <div className='footer_content'>
                    <ul>
                        <li>our feed</li>
                        <li>terms and conditions</li>
                        <li>our privacy</li>
                    </ul>
                </div>
                <div className='footer_content'>
                    <ul>
                        <li>join us</li>
                        <li>live support</li>
                    </ul>
                </div>
                <div className='footer_content'>
                    <h5>Payment Methods</h5>
                    <img src={ payment }></img>
                </div>
            </div>
        </div>
    )
}

export default Footer