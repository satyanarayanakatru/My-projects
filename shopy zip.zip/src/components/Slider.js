import React from "react";
// Import css files
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from 'react-slick';
import product_img1 from "../images/Product_Img.png";
import product_img2 from "../images/Product_Img1.png";
import product_img3 from "../images/Product_Img2.png";
import item2 from '../images/Item2.jpg';
import item3 from '../images/Item3.jpg';
import Item4 from '../images/Item4.jpg';
import item_4 from '../images/item_4.jpg';
import Item6 from '../images/Item6.jpg';
import Item7 from '../images/Item7.jpg';
import img8 from '../images/img8.png';
import item1 from '../images/item1.jpg';
import item9 from '../images/item9.jpg';
import item10 from '../images/item10.jpg';



function Responsive() {
  var settings = {
    dots: true,
    infinite: true,
    autoplay : true,
    speed: 1500,
    autoplaySpeed: 2000,
    slidesToShow: 4,
    slidesToScroll: 4,
    initialSlide: 0,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          infinite: true,
          dots: true
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          initialSlide: 2
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ]
  };
  return (
    <div className="slider-container container">
      <Slider {...settings}>
        <div>
          <div className="products_item">
            <img src={product_img1} />
            <h4>Reebok Track Jacket</h4>
            <p>80$</p>
          </div>
        </div>
        <div>
          <div className="products_item">
            <img src={product_img2} />
            <h4>Reebok Gents Jacket</h4>
            <p>100$</p>
          </div>
        </div>
        <div>
          <div className='products_item'>
            <img src={product_img3}></img>
            <h4>Gents Men Jacket</h4>
            <p>70$</p>
          </div>
        </div>
        <div>
          <div className='products_item'>
            <img src={product_img1}></img>
            <h4>Ladies Track Jacket</h4>
            <p>60$</p>
          </div>
        </div>
        <div>
          <div className='products_item'>
            <img src={item2} className="product_img"></img>
            <h4>Mens Fashion Tea Shirt</h4>
            <p>89$</p>
          </div>
        </div>
        <div>
          <div className='products_item'>
            <img src={item3} className="product_img"></img>
            <h4>Ladies  New Shirt</h4>
            <p>47$</p>
          </div>
        </div>
        <div>
          <div className='products_item'>
            <img src={Item4} className="product_img"></img>
            <h4>  Sweater For Mens</h4>
            <p>60$</p>
          </div>
        </div>
        <div>
          <div className='products_item'>
            <img src={item_4} className="product_img"></img>
            <h4>Mens Blue Fashion Shirt</h4>
            <p>90$</p>
          </div>
        </div>
        <div>
          <div className='products_item'>
            <img src={Item6} className="product_img"></img>
            <h4>Ladies  Wearable Shirt</h4>
            <p>29$</p>
          </div>
        </div>
        <div>
          <div className='products_item'>
            <img src={Item7} className="product_img"></img>
            <h4>Ladies New Shirt</h4>
            <p>34$</p>
          </div>
        </div>
        <div>
          <div className='products_item'>
            <img src={Item4} className="product_img"></img>
            <h4>Men Wearable Sweater</h4>
            <p>60$</p>
          </div>
        </div>
        <div>
          <div className='products_item'>
            <img src={item_4} className="product_img"></img>
            <h4>Mens Blue Style Shirt</h4>
            <p>90$</p>
          </div>
        </div>
        <div>
          <div className='products_item'>
            <img src={img8} className="product_img"></img>
            <h4>Ladies Fashion Shirt</h4>
            <p>29$</p>
          </div>
        </div>
        <div>
          <div className='products_item'>
            <img src={item9} className="product_img"></img>
            <h4>Ladies Summer Wearable Shirt</h4>
            <p>34$</p>
          </div>
        </div>
        <div>
          <div className='products_item'>
            <img src={item1} className="product_img"></img>
            <h4>Mens Sleeveless Shirt</h4>
            <p>89$</p>
          </div>
        </div>
        <div>
          <div className='products_item'>
            <img src={item10} className="product_img"></img>
            <h4>Ladies summer  shirt</h4>
            <p>47$</p>
          </div>
        </div>
       
      </Slider>
    </div>
  );
}

export default Responsive;

