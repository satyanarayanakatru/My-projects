import React from 'react';
import nopagefound from '../images/404-error-page.jpg';

function NoPageFound() {
  return (
    <div>
        <img src={nopagefound} className='ops_img'/>
    </div>
  )
}

export default NoPageFound;