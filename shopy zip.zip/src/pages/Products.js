import React, { useState } from 'react'
import big_img from '../images/product4.png';
import small_img1 from '../images/small_img1.png'
import small_img2 from '../images/small_img2.png'
import Newarrivals from '../components/Newarrivals';
import Newsletter from '../components/Newsletter';
import OrderPlace from './OrderPlace';
import { useNavigate } from "react-router-dom";

function Products() {
    const navigate = useNavigate()
    const [num, setNum] = useState(0);

    const handleDecrement = () => {
        setNum(num - 1);
    }
    const handleIncrement = () => {
        setNum(num + 1);
    }

   
    return (
        <>
            <div className='products'>
                <div className='container products_inner_content'>
                    <div className='products_content'>
                        <img src={big_img}></img>
                        <div className='small_images'>
                            <img src={small_img1}></img>
                            <img src={small_img2}></img>
                            <img src={small_img1}></img>
                        </div>
                    </div>
                    <div className='products_right_content'>
                        <h2>FULL WINTER KIT</h2>
                        <b>Half Jacket + Skiny Trousers + Boot leather</b>
                        <p>Lorem Ipsum is simply dummy text of the printing <br/> and typesetting industry
                            Lorem Ipsum is simply dummy text of the printing
                            and typesetting industry</p>
                        <hr></hr>
                        <span> <b>Choose Size</b>  S-M-L-XL</span>
                        <b className='quantity'>Choose Quantity <button onClick={handleDecrement} className='button'>-</button>{num}<button onClick={handleIncrement} className='button'>+</button></b>
                        <hr></hr>
                        <p className='price'><b>Price: 120$</b>
                            <span>
                                <i className='fa fa-shopping-cart'></i>
                                <i className='fa fa-heart-o'></i>
                            </span>
                            <button onClick={() => navigate('/orderplace')}>Order Now</button>
                        </p>
                    </div>
                </div>
            </div>
            <Newarrivals/>
            <Newsletter/>
        </>
    )
}


export default Products;