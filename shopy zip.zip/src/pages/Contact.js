import React from "react";
import { useState } from "react";
import { useNavigate } from 'react-router-dom';

function Contact() {
  const navigate = useNavigate();
  const [registrationResponse, setRegistrationResponse] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    mobile: '',
  });
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };


  const validateForm = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required*';
    } 

    if (!formData.email.trim()) {
      newErrors.email = 'Email address is required*';
    } else if (!/^[A-Z0-9,_%+-]+@[A-Z0-9,-]+\.[A-Z]{2,}$/i.test(formData.email)) {
      newErrors.email = 'Invalid email address';
    } 

    if (!formData.mobile.trim()) {
      newErrors.mobile = 'Mobile number is required*';
    } else if (formData.mobile.length < 10) {
      newErrors.mobile = 'Mobile number must be 10 digits'
    }
    return newErrors;

  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validateErrors = validateForm();
    if (Object.keys(validateErrors).length === 0) {
      // Form is valid, send data to the server
      try {
        const obj = {
          name: formData.email,
          job: formData.password
        }

        // API Calling

        const response = await fetch('https://reqres.in/api/users', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(obj),

        })

        const data = await response.json();
        console.log(data);
        setRegistrationResponse(data);

        if (response.ok) {
          // Handle successful submission
          console.log('Form submitted Successfully');
          //  window.open ("/submit")
          navigate('/submit');
        } else {
          // Handle server side errors
          console.error('Server error')
        }
      } catch (error) {
        // Handle network or other errors
        console.error('Network error', error);
      }
    } else {
      // update state with validation errors
      setErrors(validateErrors);
    }

  };
  return (
    <div className="container">
      <div className='jumbotron text-center'>
        <h1 className='text-primary'>Contact us</h1>
        <h2>We are here to help you</h2>
        <p>Feel free to react out us at <b>satyanarayanayadav50@gmail.com</b> </p>
      </div>
      <form onSubmit={handleSubmit}>
        <div>
          <div className="form-group">
            <label className="form-label">Name</label>
            <input type="text" className="form-control" name="name" value={formData.name} onChange={handleChange} />
            {errors.name && <p className="text-danger">{errors.name}</p>}
          </div>
          <div className="form-group">
            <label className="form-label">Email</label>
            <input type="email" className="form-control" name="email" value={formData.email} onChange={handleChange} />
            {errors.email && <p className="text-danger">{errors.email}</p>}
          </div>
          <div className="form-group">
            <label className="form-label">Mobile</label>
            <input type="tel" className="form-control" name="mobile" value={formData.mobile} onChange={handleChange} />
            {errors.mobile && <p className="text-danger">{errors.mobile}</p>}
          </div>
          <div className="form-group">
            <label className="form-label">Message</label>
            <textarea className="form-control"/>
          </div>
          <button className="btn btn-primary mt-3" type="submit" >Submit</button>
        </div>
      </form>
      {registrationResponse && <p>{registrationResponse.message}</p>}
    </div>
  )
}

export default Contact;
