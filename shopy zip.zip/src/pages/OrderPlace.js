import React from 'react';
import { useNavigate } from 'react-router-dom';
import ops from '../images/ops.jpg'

function OrderPlace() {

  const navigate = useNavigate();
  return (
    <>
        <div className='container ops'>
          <img src={ops} className='ops_img'/> <br></br>
          <button onClick={()=>navigate(-1)} className='btn btn-primary' type='button' >Go Back</button>
        </div>
    </>
  )
}

export default OrderPlace;