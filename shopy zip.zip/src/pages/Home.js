import React from 'react'
import Main from '../components/Main';
import Footer from '../components/Footer';

function Home() {
  return (
    <div>
        <Main/>
    </div>
  )
}

export default Home;