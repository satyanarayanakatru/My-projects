import React from 'react';
import { useNavigate } from 'react-router-dom';
import submit from '../images/submit.png'

function Submit() {
    const navigate = useNavigate()
  return (
    <div className='container ops'>
        <img src={ submit } className="ops_img"/>
        <button onClick={()=>navigate('/')} className='btn btn-primary m-3' >Go to Home page</button>
    </div>
  )
}

export default Submit;