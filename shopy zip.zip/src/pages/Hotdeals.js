import React from 'react'
import Newarrivals from '../components/Newarrivals';
import Newsletter from '../components/Newsletter';
import item2 from '../images/Item2.jpg';
import item3 from '../images/Item3.jpg';
import Item4 from '../images/Item4.jpg';
import item_4 from '../images/item_4.jpg';
import Item6 from '../images/Item6.jpg';
import Item7 from '../images/Item7.jpg';


function Hotdeals() {
  return (
    <>
        <div className='container'>
            <h2 className='hot_deals'><span>Hot</span> Deals</h2>
            <div className="section_1">
                <div className="items">
                    <img src={item2} alt="" className="image"/>
                    <img src={item3} alt="" className="image"/>
                    <img src={Item4} alt="" className="items_inner"/>
                </div>
                <div className="items">
                    <img src={item_4} alt="" className="items_inner inner"/>
                    <img src={Item6} alt="" className="image"/>
                    <img src={Item7} alt="" className="image"/>
                </div>
            </div>
            
        </div>
        <Newarrivals/>
        <Newsletter/>
        
    </>
  )
}

export default Hotdeals