import React from 'react';
import map from "../images/map.jpg"

function About() {
    return (
        <>
            <div className='about_page'>
                <div className='container'>
                    <div class="main_countries">
                        <div class="countries">
                            <h2>London</h2>
                            <h4>180-182 Regent Street, London, W1B 5BT</h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing esi elit. Vivamus at arcu sem. Vestibulum
                                ornare eleifendit massa, nec tempor odio. Fusce posuere nunc iaculis ligula viverra iaculis.
                                Aliquam erat volutpat.</p>
                            <button>ViEW DETAILS</button>
                        </div>
                        <div class="countries">
                            <h2>New York</h2>
                            <h4>109 Columbus Circle, New York, NY 10023</h4>
                            <p>Nunc non posuere nisl. Etiam finibus vel dui nec lobortis. Aliquam egestas, sem quis condimentum
                                venenatis, erat leo fermentum dolor, non sollicitudin massa mi eu nibh. Nullam vitae aliquam
                                dui, non sodales nisl.</p>
                            <button>ViEW DETAILS</button>
                        </div>
                        <div class="countries">
                            <h2>Paris</h2>
                            <h4>2133 Rue Saint-Honoré, 75001 Paris</h4>
                            <p>Ut interdum fermentum blandit. Donec nec lacus egetit mi rhoncus eleifend. Curabitur laoreet nisl
                                eget rutruml auctor. Vestibulum ante ipsum primis in faucibus orcip luctus et ultrices posuere
                                cubilia curae cras ligula.</p>
                            <button>ViEW DETAILS</button>
                        </div>
                    </div>
                </div>
                <div class="map">
                    <img src={map} alt="" />
                    <div class="map_details">
                        <h2>London</h2>
                        <h4>180-182 Regent Street, London, W1B 5BT</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing esi elit. Vivamus at arcu sem. Vestibulum
                            ornare eleifendit massa, nec tempor odio. Fusce posuere nunc iaculis ligula viverra iaculis.
                            Aliquam erat volutpat.</p>
                        <p><i class="fa fa-map-marker" aria-hidden="true"></i> 180-182 Regent Street, London,
                            W1B 5BT</p>
                        <p><i className="fa fa-phone" aria-hidden="true"></i>0123-456-789</p>
                        <p><i className="fa fa-link" aria-hidden="true"></i>www.yourwebsite.com</p>
                        <p><i className="fa fa-envelope-o" aria-hidden="true"></i>support@yourwebsite.com</p>
                        <p><i className="fa fa-clock-o" aria-hidden="true"></i>Monday-Friday: 9am to 6pm Saturday:
                            10am to 6pm
                            Sunday: 10am to 2pm</p>
                        <i className="fa fa-facebook map_icons" aria-hidden="true"></i>
                        <i className="fa fa-twitter map_icons" aria-hidden="true"></i>
                        <i className="fa fa-instagram map_icons" aria-hidden="true"></i>
                        <i className="fa fa-pinterest-p map_icons" aria-hidden="true"></i>
                    </div>
                </div>
            </div>
        </>
    )
}

export default About