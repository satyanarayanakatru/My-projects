$(document).ready(function(){
    $(".section8_content").bxSlider();
        autoplay : true,
        slideToShow 
});