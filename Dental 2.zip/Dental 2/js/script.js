

var wrapper=document.getElementsByClassName("wrapper");
wrapper[0].setAttribute("style","background-image:url(images/Background.jpg); padding:20px 0");

var container = document.getElementsByClassName("container");
container[0].setAttribute("style", "width:900px; margin:0 auto; background-color:#ffffff;text-align:center" );

var nav = document.getElementsByClassName("nav");
nav[0].setAttribute("style", "background-color:#005185;");

var logo = document.getElementsByClassName("logo");
logo[0].setAttribute("style", "padding:30px 0")

var li = document.getElementsByTagName("li");
for(let i=0;i<li.length;i++){
    li[i].setAttribute("style", "display:inline-block; margin-right:30px");
}
var ul = document.getElementsByTagName("ul");
ul[0].setAttribute("style","list-style-type:none; padding:10px 0");

var a = document.getElementsByTagName("a");

for(var i=0;i<a.length;i++){
    a[i].setAttribute("style", "color:white; font-size:18px; line-height:20px; text-decoration:none");
}
var home = document.getElementsByClassName("home");
for(var i=0;i<home.length;i++){
    home[i].setAttribute("style", "background-color:#088bdf; border-radius:5px; padding: 3px 10px; color:white; text-decoration:none")
}

var m = document.getElementsByClassName("main");
m[0].setAttribute("style","display:flex; justify-content:space-between;");

var h4 = document.querySelectorAll("h4");
h4[0].setAttribute("style","color:#0070b8; text-align:left; padding-bottom:5px");
h4[1].setAttribute("style","color:#0070b8; text-align:left; padding-bottom:5px");
h4[2].setAttribute("style","color:#0070b8; text-align:left; padding-bottom:5px");

var p = document.getElementsByTagName("p");
for(var i=0;i<p.length;i++){
    p[i].setAttribute("style", "text-align:justify;text-align: justify; font-size:13px; line-height:16px; padding:5px 0 10px 0");
}

var footer = document.getElementsByTagName("footer");
footer[0].setAttribute("style", "background-color: #0369ac;");

var content1 = document.getElementsByClassName("content1");
content1[0].setAttribute("style"," margin-right:20px; padding:20px");

var content2 = document.getElementsByClassName("content2");
content2[0].setAttribute("style", "background-color:#d9eaf4; padding:20px");

var footer_p = document.getElementsByClassName("footer_p");
footer_p[0].setAttribute("style", "text-align:right; color:#ffffff; padding:15px");

var img = document.getElementsByTagName("img");
img[1].setAttribute("style", "width:100%");
img[2].setAttribute("style", "width:100%");
img[3].setAttribute("style", "width:100%");